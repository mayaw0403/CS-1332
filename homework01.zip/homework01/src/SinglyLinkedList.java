import java.util.NoSuchElementException;
/**
 * Your implementation of a non-circular SinglyLinkedList with a tail pointer.
 *
 * @author Maya Williams
 * @version 1.0
 * @userid mwilliams480
 * @GTID 903668557
 * I did not collaborate with anyone.
 */
public class SinglyLinkedList<T> {

    // Do not add new instance variables or modify existing ones.
    private SinglyLinkedListNode<T> head;
    private SinglyLinkedListNode<T> tail;
    private int size;

    // Do not add a constructor.

    /**
     * Adds the element to the specified index.
     *
     * Must be O(1) for indices 0 and size and O(n) for all other cases.
     *
     * @param index the index to add the new element
     * @param data  the data to add
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index > size
     * @throws java.lang.IllegalArgumentException  if data is null
     */
    public void addAtIndex(int index, T data) {
        SinglyLinkedListNode<T> mainNode = new SinglyLinkedListNode<T>(data);
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("The data can't be added at index since index < 0 or index > size");
        } else if (data == null) {
            throw new IllegalArgumentException("The data can't be added at index since it is null");
        } else if (index == size) {
            addToBack(data);
        } else if (index == 0) {
            addToFront(data);
        } else {
            SinglyLinkedListNode<T> currentNode = head;
            for (int i = 1; i < index; i++) {
                currentNode = currentNode.getNext();
            }
            mainNode.setNext(currentNode.getNext());
            currentNode.setNext(mainNode);
            size++;
        }
    }

    /**
     * Adds the element to the front of the list.
     *
     * Must be O(1).
     *
     * @param data the data to add to the front of the list
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToFront(T data) {
        SinglyLinkedListNode<T> mainNode = new SinglyLinkedListNode<T>(data);
        if (data == null) {
            throw new IllegalArgumentException("The data can't be added to front since it is null");
        } else if (head == null) {
            head = mainNode;
            tail = mainNode;
            size++;
        } else {
            mainNode.setNext(head);
            head = mainNode;
            size++;
        }
    }

    /**
     * Adds the element to the back of the list.
     *
     * Must be O(1).
     *
     * @param data the data to add to the back of the list
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToBack(T data) {
        SinglyLinkedListNode<T> mainNode = new SinglyLinkedListNode<T>(data);
        if (data == null) {
            throw new IllegalArgumentException("The data can't be added to back since it is null");
        } else if (head == null) {
            head = mainNode;
            tail = mainNode;
            size++;
        } else {
            tail.setNext(mainNode);
            tail = mainNode;
            size++;
        }
    }

    /**
     * Removes and returns the element at the specified index.
     *
     * Must be O(1) for indices 0 and O(n) for all other
     * cases.
     *
     * @param index the index of the element to remove
     * @return the data that was removed
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index >= size
     */
    public T removeAtIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Removing the node at the index can't occur "
                    + "since index < 0 or index >= size");
        } else if (index == 0) {
            return removeFromFront();
        } else if (index == size - 1) {
            return removeFromBack();
        } else {
            SinglyLinkedListNode<T> currentNode = head;
            for (int i = 1; i < index; i++) {
                currentNode = currentNode.getNext();
            }
            SinglyLinkedListNode<T> temporaryNode = currentNode.getNext();
            currentNode.setNext(currentNode.getNext().getNext());
            size--;
            return temporaryNode.getData();
        }
    }

    /**
     * Removes and returns the first data of the list.
     *
     * Must be O(1).
     *
     * @return the data formerly located at the front of the list
     * @throws java.util.NoSuchElementException if the list is empty
     */
    public T removeFromFront() {
        if (head == null) {
            throw new NoSuchElementException("Can't remove from front since the list is empty");
        } else if (size == 1) {
            SinglyLinkedListNode<T> temporaryNode = head;
            head = null;
            tail = null;
            size--;
            return temporaryNode.getData();
        } else {
            SinglyLinkedListNode<T> temporaryNode = head;
            head = head.getNext();
            size--;
            return temporaryNode.getData();
        }
    }

    /**
     * Removes and returns the last data of the list.
     *
     * Must be O(n).
     *
     * @return the data formerly located at the back of the list
     * @throws java.util.NoSuchElementException if the list is empty
     */
    public T removeFromBack() {
        SinglyLinkedListNode<T> currentNode = head;
        if (head == null) {
            throw new NoSuchElementException("Can't remove from back since list is empty");
        } else if (size == 1) {
            SinglyLinkedListNode<T> temporaryNode = head;
            head = null;
            tail = null;
            size--;
            return temporaryNode.getData();
        } else {
            while (currentNode.getNext().getNext() != null) {
                currentNode = currentNode.getNext();
            }
            SinglyLinkedListNode<T> temporaryNode = currentNode.getNext();
            currentNode.setNext(null);
            tail = currentNode;
            size--;
            return temporaryNode.getData();
        }
    }

    /**
     * Returns the element at the specified index.
     *
     * Must be O(1) for indices 0 and size - 1 and O(n) for all other cases.
     *
     * @param index the index of the element to get
     * @return the data stored at the index in the list
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index >= size
     */
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Can't get the element at the index "
                    + "since the index < 0 or index >= size");
        } else if (index == 0) {
            return head.getData();
        } else if (index == size - 1) {
            return tail.getData();
        } else {
            SinglyLinkedListNode<T> currentNode = head;
            for (int i = 0; i < index; i++) {
                currentNode = currentNode.getNext();
            }
            return currentNode.getData();
        }
    }

    /**
     * Returns whether or not the list is empty.
     *
     * Must be O(1).
     *
     * @return true if empty, false otherwise
     */
    public boolean isEmpty() {
        return head == null;
    }

    /**
     * Clears the list.
     *
     * Clears all data and resets the size.
     *
     * Must be O(1).
     */
    public void clear() {
        head = null;
        tail = null;
        size = 0;
    }

    /**
     * Removes and returns the last copy of the given data from the list.
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the list.
     *
     * Must be O(n).
     *
     * @param data the data to be removed from the list
     * @return the data that was removed
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if data is not found
     */
    public T removeLastOccurrence(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't remove last occurrence since the data passed in is null");
        } else {
            SinglyLinkedListNode<T> topNode = head;
            SinglyLinkedListNode<T> otherNode = null;
            SinglyLinkedListNode<T> currentNode = null;
            while (topNode != null) {
                if (topNode.getNext() != null && topNode.getNext().getData().equals(data)) {
                    otherNode = topNode;
                    currentNode = topNode.getNext();
                }
                topNode = topNode.getNext();
            }
            if (head.getData().equals(data) && tail.getData().equals(data)) {
                SinglyLinkedListNode<T> temporaryNode = head;
                clear();
                return temporaryNode.getData();
            } else if (head.getData().equals(data)) {
                SinglyLinkedListNode<T> temporaryNode = head;
                head = head.getNext();
                size--;
                return temporaryNode.getData();
            } else if (tail.getData().equals(data)) {
                SinglyLinkedListNode<T> temporaryNode = head;
                while (temporaryNode.getNext().getNext() != null) {
                    temporaryNode = temporaryNode.getNext();
                }
                SinglyLinkedListNode<T> newTemp = temporaryNode.getNext();
                temporaryNode.setNext(null);
                tail = temporaryNode;
                size--;
                return newTemp.getData();
            } else if (otherNode != null) {
                otherNode.setNext(currentNode.getNext());
                size--;
                return currentNode.getData();
            } else {
                throw new NoSuchElementException("Can't remove last occurrence since the data was not found");
            }
        }       
    }

    /**
     * Returns an array representation of the linked list.
     *
     * Must be O(n) for all cases.
     *
     * @return the array of length size holding all of the data (not the
     * nodes) in the list in the same order
     */
    @SuppressWarnings("unchecked")
    public T[] toArray() {
        T[] anArray = (T[]) new Object[size];
        SinglyLinkedListNode<T> currentNode = head;
        for (int i = 0; i < size; i++) {
            anArray[i] = currentNode.getData();
            currentNode = currentNode.getNext();
        }
        return anArray;
    }

    /**
     * Returns the head node of the list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the node at the head of the list
     */
    public SinglyLinkedListNode<T> getHead() {
        // DO NOT MODIFY!
        return head;
    }

    /**
     * Returns the tail node of the list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the node at the tail of the list
     */
    public SinglyLinkedListNode<T> getTail() {
        // DO NOT MODIFY!
        return tail;
    }

    /**
     * Returns the size of the list.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the size of the list
     */
    public int size() {
        // DO NOT MODIFY!
        return size;
    }
}
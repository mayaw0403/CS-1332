import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.PriorityQueue;

/**
 * Your implementation of various sorting algorithms.
 *
 * @author Maya Williams
 * @version 1.0
 * @userid mwilliams480
 * @GTID 903668557
 *
 * Collaborators: LIST ALL COLLABORATORS YOU WORKED WITH HERE- None
 *
 * Resources: LIST ALL NON-COURSE RESOURCES YOU CONSULTED HERE- None
 */
public class Sorting {

    /**
     * Implement selection sort.
     *
     * It should be:
     * in-place
     * unstable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n^2)
     *
     * And a best case running time of:
     * O(n^2)
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void selectionSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Can't do the selection sort since array or comparator is null");
        }
        for (int i = 0; i < arr.length - 1; i++) {
            int minimum = i;
            for (int k = +i + 1; k < arr.length; k++) {
                if (comparator.compare(arr[k], arr[minimum]) < 0) {
                    minimum = k;
                }
            }
            T temporary = arr[i];
            arr[i] = arr[minimum];
            arr[minimum] = temporary;
        }
    }

    /**
     * Implement insertion sort.
     *
     * It should be:
     * in-place
     * stable
     * adaptive
     *
     * Have a worst case running time of:
     * O(n^2)
     *
     * And a best case running time of:
     * O(n)
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void insertionSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Can't do the insertion sort since array or comparator is null");
        }
        for (int i = 1; i < arr.length; i++) {
            int k = i - 1;
            T temporary = arr[i];
            while (k >= 0 && comparator.compare(arr[k], temporary) > 0) {
                arr[k + 1] = arr[k];
                k--;
            }
            arr[k + 1] = temporary;
        }
    }

    /**
     * Implement bubble sort.
     *
     * It should be:
     * in-place
     * stable
     * adaptive
     *
     * Have a worst case running time of:
     * O(n^2)
     *
     * And a best case running time of:
     * O(n)
     *
     * NOTE: See pdf for last swapped optimization for bubble sort. You
     * MUST implement bubble sort with this optimization
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void bubbleSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Can't do the bubble sort since array or comparator is null");
        }
        int endIndex = arr.length - 1;
        while (endIndex != 0) {
            int i = 0;
            int last = 0;
            while (i < endIndex) {
                if (comparator.compare(arr[i], arr[i + 1]) > 0) {
                    T temporary = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temporary;
                    last = i;
                }
                i++;
            }
            endIndex = last;
        }
    }

    /**
     * Implement merge sort.
     *
     * It should be:
     * out-of-place
     * stable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n log n)
     *
     * And a best case running time of:
     * O(n log n)
     *
     * You can create more arrays to run merge sort, but at the end, everything
     * should be merged back into the original T[] which was passed in.
     *
     * When splitting the array, if there is an odd number of elements, put the
     * extra data on the right side.
     *
     * Hint: If two data are equal when merging, think about which subarray
     * you should pull from first
     *
     * @param <T>        data type to sort
     * @param arr        the array to be sorted
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is
     *                                            null
     */
    public static <T> void mergeSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Can't do merge sort since array or comparator is null");
        }
        if (arr.length <= 1) {
            return;
        } else {
            int fullLength = arr.length;
            int mid = fullLength / 2;
            T[] left = (T[]) new Object[mid];
            T[] right = (T[]) new Object[fullLength - mid];
            for (int i = 0; i < mid; i++) {
                left[i] = arr[i];
            }
            for (int i = mid; i < fullLength; i++) {
                right[i - mid] = arr[i];
            }
            mergeSort(left, comparator);
            mergeSort(right, comparator);
            merge(arr, comparator, left, right);
        }
    }
    
    /**
     * Helper method for the merge sort
     * @param <T>        data type to sort
     * @param arr        the array to be sorted
     * @param comparator the Comparator used to compare the data in arr
     * @param left the left item
     * @param right the right item
     */

    private static <T> void merge(T[] arr, Comparator<T> comparator, T[] left, T[] right) {
        int i = 0;
        int k = 0;
        while (i < left.length && k < right.length) {
            if (comparator.compare(left[i], right[k]) <= 0) {
                arr[i + k] = left[i];
                i++;
            } else {
                arr[i + k] = right[k];
                k++;
            }
        }
        while (i < left.length) {
            arr[i + k] = left[i];
            i++;
        }
        while (k < right.length) {
            arr[i + k] = right[k];
            k++;
        }
    }

    /**
     * Implement LSD (least significant digit) radix sort.
     *
     * Make sure you code the algorithm as you have been taught it in class.
     * There are several versions of this algorithm and you may not get full
     * credit if you do not implement the one we have taught you!
     *
     * Remember you CANNOT convert the ints to strings at any point in your
     * code! Doing so may result in a 0 for the implementation.
     *
     * It should be:
     * out-of-place
     * stable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(kn)
     *
     * And a best case running time of:
     * O(kn)
     *
     * You are allowed to make an initial O(n) passthrough of the array to
     * determine the number of iterations you need.
     *
     * At no point should you find yourself needing a way to exponentiate a
     * number; any such method would be non-O(1). Think about how how you can
     * get each power of BASE naturally and efficiently as the algorithm
     * progresses through each digit.
     *
     * Refer to the PDF for more information on LSD Radix Sort.
     *
     * You may use ArrayList or LinkedList if you wish, but it may only be
     * used inside radix sort and any radix sort helpers. Do NOT use these
     * classes with other sorts. However, be sure the List implementation you
     * choose allows for stability while being as efficient as possible.
     *
     * Do NOT use anything from the Math class except Math.abs().
     *
     * @param arr the array to be sorted
     * @throws java.lang.IllegalArgumentException if the array is null
     */
    public static void lsdRadixSort(int[] arr) {
        if (arr == null) {
            throw new IllegalArgumentException("Can't do lsd Radix Sort since the array is null");
        }

        List<Integer>[] bkts = new ArrayList[19];
        int longer = arr[0];
        int longLen = 1; 

        for (int i = 0; i < arr.length; i++) {
            int current = Math.abs(arr[i]);
            if (current > longer) {
                longer = current;
            }
        }

        while (longer >= 10) {
            longer = (int) longer / 10;
            longLen += 1;
        }

        int temporary = 1;
        for (int i = 0; i < longLen; i++) {
            int arrayIndex = 0;

            for (int k = 0; k < arr.length; k++) {
                int current = arr[k] / temporary;
                int bkt = (current % 10) + 9;

                if (bkts[bkt] == null) {
                    bkts[bkt] = new ArrayList<Integer>();
                }
                bkts[bkt].add(arr[k]);
            }

            temporary *= 10;
            for (int k = 0; k < bkts.length; k++) {
                if (bkts[k] != null) {
                    for (Integer integer1 : bkts[k]) {
                        arr[arrayIndex] = integer1;
                        arrayIndex++;
                    }
                    bkts[k] = null;
                }
            }
        }
    }

    /**
     * Implement heap sort.
     *
     * It should be:
     * out-of-place
     * unstable
     * not adaptive
     *
     * Have a worst case running time of:
     * O(n log n)
     *
     * And a best case running time of:
     * O(n log n)
     *
     * Use java.util.PriorityQueue as the heap. Note that in this
     * PriorityQueue implementation, elements are removed from smallest
     * element to largest element.
     *
     * Initialize the PriorityQueue using its build heap constructor (look at
     * the different constructors of java.util.PriorityQueue).
     *
     * Return an int array with a capacity equal to the size of the list. The
     * returned array should have the elements in the list in sorted order.
     *
     * @param data the data to sort
     * @return the array with length equal to the size of the input list that
     * holds the elements from the list is sorted order
     * @throws java.lang.IllegalArgumentException if the data is null
     */
    public static int[] heapSort(List<Integer> data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't do the heap sort since the data is null");
        }
        PriorityQueue<Integer> priority = new PriorityQueue<>(data);
        int[] sorted = new int[data.size()];
        for (int i = 0; i < data.size(); i++) {
            sorted[i] = priority.remove();
        }
        return sorted;
    }
}
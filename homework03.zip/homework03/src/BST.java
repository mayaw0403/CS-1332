import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;

/**
 * Your implementation of a BST.
 *
 * @author Maya Williams
 * @version 1.0
 * @userid mwilliams480
 * @GTID 903668557
 *
 * Collaborators: LIST ALL COLLABORATORS YOU WORKED WITH HERE- None
 *
 * Resources: LIST ALL NON-COURSE RESOURCES YOU CONSULTED HERE- None
 */
public class BST<T extends Comparable<? super T>> {

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private BSTNode<T> root;
    private int size;

    /**
     * Constructs a new BST.
     *
     * This constructor should initialize an empty BST.
     *
     * Since instance variables are initialized to their default values, there
     * is no need to do anything for this constructor.
     */
    public BST() {
        // DO NOT IMPLEMENT THIS CONSTRUCTOR!
    }

    /**
     * Constructs a new BST.
     *
     * This constructor should initialize the BST with the data in the
     * Collection. The data should be added in the same order it is in the
     * Collection.
     *
     * Hint: Not all Collections are indexable like Lists, so a regular for loop
     * will not work here. However, all Collections are Iterable, so what type
     * of loop would work?
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data or any element in data
     *                                            is null
     */
    public BST(Collection<T> data) {
        this.size = 0;
        if (data == null) {
            throw new IllegalArgumentException("Data or any element in data is null since data can't be added");
        }
        for (T i : data) {
            if (i == null) {
                throw new IllegalArgumentException("Data or any element in data is null since data can't be added");
            } else {
                add(i);
            }
        }
    }

    /**
     * Adds the data to the tree.
     *
     * This must be done recursively.
     *
     * The data becomes a leaf in the tree.
     *
     * Traverse the tree to find the appropriate location. If the data is
     * already in the tree, then nothing should be done (the duplicate
     * shouldn't get added, and size should not be incremented).
     *
     * Must be O(log n) for best and average cases and O(n) for worst case.
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void add(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't add null data into the tree");
        } else {
            root = helperAdd(root, data);
        }
    }

    /**
     * Helper method for the add method
     * @param data the data to add
     * @param current the current BSTNode
     * @return the current BSTNode
     */
    private BSTNode<T> helperAdd(BSTNode<T> current, T data) {
        if (current == null) {
            size++;
            return new BSTNode<T>(data);
        } else if (data.compareTo(current.getData()) < 0) {
            current.setLeft(helperAdd(current.getLeft(), data));
        } else if (data.compareTo(current.getData()) > 0) {
            current.setRight(helperAdd(current.getRight(), data));
        }
        return current;
    }

    /**
     * Removes and returns the data from the tree matching the given parameter.
     *
     * This must be done recursively.
     *
     * There are 3 cases to consider:
     * 1: The node containing the data is a leaf (no children). In this case,
     * simply remove it.
     * 2: The node containing the data has one child. In this case, simply
     * replace it with its child.
     * 3: The node containing the data has 2 children. Use the successor to
     * replace the data. You MUST use recursion to find and remove the
     * successor (you will likely need an additional helper method to
     * handle this case efficiently).
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the tree.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Must be O(log n) for best and average cases and O(n) for worst case.
     *
     * @param data the data to remove
     * @return the data that was removed
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not in the tree
     */
    public T remove(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't remove null data from the tree");
        } else {
            BSTNode<T> trial = new BSTNode<T>(null);
            root = helperRemove(root, data, trial);
            return trial.getData();
        }

    }

    /**
     * Helper method for the remove method
     * @param data the data to remove
     * @param current the current BSTNode
     * @param trial the trial BSTNode to store the removed BSTNode
     * @return the current BSTNode
     */
    private BSTNode helperRemove(BSTNode<T> current, T data, BSTNode<T> trial) {
        if (current == null) {
            throw new NoSuchElementException("Can't remove data since it is not in the tree");
        } else if (data.compareTo(current.getData()) < 0) {
            current.setLeft(helperRemove(current.getLeft(), data, trial));
        } else if (data.compareTo(current.getData()) > 0) {
            current.setRight(helperRemove(current.getRight(), data, trial));
        } else {
            trial.setData(current.getData());
            size--;
            if (current.getLeft() == null && current.getRight() == null) {
                return null;
            } else if (current.getLeft() != null && current.getRight() == null) {
                return current.getLeft();
            } else if (current.getRight() != null && current.getLeft() == null) {
                return current.getRight();
            } else {
                BSTNode<T> trial1 = new BSTNode<T>(null);
                current.setRight(removeSuccessor(current.getRight(), trial1));
                current.setData(trial1.getData());
            }
        }
        return current;
    }

    /**
     * Remove successor method that helps the remove helper method
     * @param current the current BSTNode
     * @param trial the trial BSTNode that stores the removed BSTNode
     * @return the current BSTNode
     */
    private BSTNode<T> removeSuccessor(BSTNode<T> current, BSTNode<T> trial) {
        if (current.getLeft() == null) {
            trial.setData(current.getData());
            return current.getRight();
        } else {
            current.setLeft(removeSuccessor(current.getLeft(), trial));
        }
        return current;
    }

    /**
     * Returns the data from the tree matching the given parameter.
     *
     * This must be done recursively.
     *
     * Do not return the same data that was passed in. Return the data that
     * was stored in the tree.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Must be O(log n) for best and average cases and O(n) for worst case.
     *
     * @param data the data to search for
     * @return the data in the tree equal to the parameter
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not in the tree
     */
    public T get(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't get that data since it is null");
        } else {
            BSTNode<T> trial = new BSTNode<T>(null);
            getHelper(root, data, trial);
            return trial.getData();
        }
    }

    /**
     * Helper method for the get method
     * @param current the current BSTNode
     * @param data the data to get
     * @param trial trial BSTNode to store the data to get
     * @return the BSTNode that has the data looked for
     */
    private BSTNode<T> getHelper(BSTNode<T> current, T data, BSTNode<T> trial) {
        if (data.compareTo(current.getData()) < 0 && current.getLeft() != null) {
            return getHelper(current.getLeft(), data, trial);
        } else if (data.compareTo(current.getData()) > 0 && current.getRight() != null) {
            return getHelper(current.getRight(), data, trial);
        } else if (data.compareTo(current.getData()) == 0) {
            trial.setData(current.getData());
            return current;
        } else {
            throw new NoSuchElementException("Can't get data that doesn't exist in the tree");
        }
    }

    /**
     * Returns whether or not data matching the given parameter is contained
     * within the tree.
     *
     * This must be done recursively.
     *
     * Hint: Should you use value equality or reference equality?
     *
     * Must be O(log n) for best and average cases and O(n) for worst case.
     *
     * @param data the data to search for
     * @return true if the parameter is contained within the tree, false
     * otherwise
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public boolean contains(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't inspect contains since data is null");
        } else {
            if (root == null) {
                return false;
            } else {
                return helperContains(root, data);
            }
        }
    }

    /**
     * Helper method for the contains method
     * @param current the current BSTNode
     * @param data the data to search for
     * @return the boolean whether the data is contained
     */
    private boolean helperContains(BSTNode<T> current, T data) {
        if (data.compareTo(current.getData()) < 0) {
            if (current.getLeft() == null) {
                return false;
            } else {
                return helperContains(current.getLeft(), data);
            }
        } else if (data.compareTo(current.getData()) > 0) {
            if (current.getRight() == null) {
                return false;
            } else {
                return helperContains(current.getRight(), data);
            }
        } else {
            return true;
        }
    }


    /**
     * Generate a pre-order traversal of the tree.
     *
     * This must be done recursively.
     *
     * Must be O(n).
     *
     * @return the preorder traversal of the tree
     */
    public List<T> preorder() {
        List<T> list = new ArrayList<T>();
        helperPreorder(list, root);
        return list;
    }

    /**
     * Helper method for the preorder method
     * @param list the list that adds the data
     * @param current the current BSTNode
     */
    private void helperPreorder(List<T> list, BSTNode<T> current) {
        if (current != null) {
            list.add(current.getData());
            helperPreorder(list, current.getLeft());
            helperPreorder(list, current.getRight());
        }
    }

    /**
     * Generate an in-order traversal of the tree.
     *
     * This must be done recursively.
     *
     * Must be O(n).
     *
     * @return the inorder traversal of the tree
     */
    public List<T> inorder() {
        List<T> list = new ArrayList<T>();
        helperInorder(list, root);
        return list;
    }

    /**
     * Helper method for the inorder method
     * @param list the list that adds the data
     * @param current the current BSTNode
     */
    private void helperInorder(List<T> list, BSTNode<T> current) {
        if (current != null) {
            helperInorder(list, current.getLeft());
            list.add(current.getData());
            helperInorder(list, current.getRight());
        }
    }

    /**
     * Generate a post-order traversal of the tree.
     *
     * This must be done recursively.
     *
     * Must be O(n).
     *
     * @return the postorder traversal of the tree
     */
    public List<T> postorder() {
        List<T> list = new ArrayList<T>();
        helperPostorder(list, root);
        return list;
    }

    /**
     * Helper method for the postorder method
     * @param list the list that adds the data
     * @param current the current BSTNode
     */
    private void helperPostorder(List<T> list, BSTNode<T> current) {
        if (current != null) {
            helperPostorder(list, current.getLeft());
            helperPostorder(list, current.getRight());
            list.add(current.getData());
        }
    }

    /**
     * Generate a level-order traversal of the tree.
     *
     * This does not need to be done recursively.
     *
     * Hint: You will need to use a queue of nodes. Think about what initial
     * node you should add to the queue and what loop / loop conditions you
     * should use.
     *
     * Must be O(n).
     *
     * @return the level order traversal of the tree
     */
    public List<T> levelorder() {
        Queue<BSTNode<T>> queue1 = new LinkedList<BSTNode<T>>();
        List<T> list = new ArrayList<T>();
        queue1.add(root);
        while (!queue1.isEmpty()) {
            BSTNode<T> current = queue1.poll();
            list.add(current.getData());
            if (current.getLeft() != null) {
                queue1.add(current.getLeft());
            }
            if (current.getRight() != null) {
                queue1.add(current.getRight());
            }
        }
        return list;
    }

    /**
     * Returns the height of the root of the tree.
     *
     * This must be done recursively.
     *
     * A node's height is defined as max(left.height, right.height) + 1. A
     * leaf node has a height of 0 and a null child has a height of -1.
     *
     * Must be O(n).
     *
     * @return the height of the root of the tree, -1 if the tree is empty
     */
    public int height() {
        return helperHeight(root);
    }

    /**
     * Helper method for the height method
     * @param current the current BSTNode
     * @return the height of the BSTNode
     */
    private int helperHeight(BSTNode<T> current) {
        if (current == null) {
            return -1;
        } else {
            return 1 + Math.max(helperHeight(current.getLeft()), helperHeight(current.getRight()));
        }
    }

    /**
     * Clears the tree.
     *
     * Clears all data and resets the size.
     *
     * Must be O(1).
     */
    public void clear() {
        root = null;
        size = 0;
    }

    /**
     * Removes all elements strictly greater than the passed in data.
     *
     * This must be done recursively.
     *
     * In most cases, this method will not need to traverse the entire tree to
     * function properly, so you should only traverse the branches of the tree
     * necessary to get the data and only do so once. Failure to do so will
     * result in an efficiency penalty.
     *
     * EXAMPLE: Given the BST below composed of Integers:
     *
     *                50
     *              /    \
     *            25      75
     *           /  \
     *          12   37
     *         /  \    \
     *        10  15    40
     *           /
     *          13
     *
     * pruneGreaterThan(27) should remove 37, 40, 50, 75. Below is the resulting BST
     *             25
     *            /
     *          12
     *         /  \
     *        10  15
     *           /
     *          13
     *
     * Should have a running time of O(n) for a degenerate tree and O(log(n)) for a balanced tree.
     *
     * @throws java.lang.IllegalArgumentException if data is null
     * @param data the threshold data. Elements greater than data should be removed
     * @param tree the root of the tree to prune nodes from
     * @param <T> the generic typing of the data in the BST
     * @return the root of the tree with all elements greater than data removed
     */
    public static <T extends Comparable<? super T>> BSTNode<T> pruneGreaterThan(BSTNode<T> tree, T data) {
        if (data == null) {
            throw new IllegalArgumentException("Can't prune greater than since data is null");
        } else {
            return helperPruneGreaterThan(tree, data);
        }
    }

    /**
     * Helper method for the prune greater than method
     * @param current the current BSTNode
     * @param data the data being used to prune greater than BSTNodes
     * @param <T> generic parameter T
     * @return the current BSTNode is returned

     */
    private static <T extends Comparable<? super T>> BSTNode<T> helperPruneGreaterThan(BSTNode<T> current, T data) {
        if (current == null) {
            return null;
        }
        if (data.compareTo(current.getData()) < 0) {
            current.setLeft(helperPruneGreaterThan(current.getLeft(), data));
            return current.getLeft();
        } else {
            current.setRight(helperPruneGreaterThan(current.getRight(), data));
            return current;
        }
    }


    /**
     * Returns the root of the tree.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the root of the tree
     */
    public BSTNode<T> getRoot() {
        // DO NOT MODIFY THIS METHOD!
        return root;
    }

    /**
     * Returns the size of the tree.
     *
     * For grading purposes only. You shouldn't need to use this method since
     * you have direct access to the variable.
     *
     * @return the size of the tree
     */
    public int size() {
        // DO NOT MODIFY THIS METHOD!
        return size;
    }
}